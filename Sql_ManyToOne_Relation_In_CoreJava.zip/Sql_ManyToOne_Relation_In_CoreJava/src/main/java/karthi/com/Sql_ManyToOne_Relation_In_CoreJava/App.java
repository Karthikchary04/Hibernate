package karthi.com.Sql_ManyToOne_Relation_In_CoreJava;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import model.Course;
import model.Student;

public class App 
{
    public static void main( String[] args )
    {
       Configuration cfg=new Configuration().configure().addAnnotatedClass(Student.class).addAnnotatedClass(Course.class);
       SessionFactory sf=cfg.buildSessionFactory();
       Session ss=sf.openSession();
       Transaction t=ss.beginTransaction();
       
       Student s=new Student();
       s.setSid(101);
       s.setName("karthik");
       s.setEmail("karthik@gmail.com");
       s.setCity("hyd");
       
       Course c=new Course();
       c.setCid(201);
       c.setCname("pgp java");
       c.setStudent(s);
       s.getCourse().add(c);
       
       ss.save(c);
       ss.save(s);
       t.commit();
       sf.close();		   
    }
}
