package model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Customer 
{
	@Id
    private int cid;
	private String name,email,city;
	@OneToMany
	private List<SalesPerson> salesPersons=new ArrayList<SalesPerson>();
	
	public List<SalesPerson> getSalesPersons() {
		return salesPersons;
	}
	public void setSalesPersons(List<SalesPerson> salesPersons) {
		this.salesPersons = salesPersons;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
}
