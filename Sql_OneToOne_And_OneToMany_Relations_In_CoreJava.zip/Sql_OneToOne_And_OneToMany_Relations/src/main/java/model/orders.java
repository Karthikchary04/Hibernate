package model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class orders 
{
	@Id
    private int oid;
    private int oamt;
    private String productname;
    
    @OneToOne
    private SalesPerson salesperson;
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public int getOamt() {
		return oamt;
	}
	public void setOamt(int oamt) {
		this.oamt = oamt;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public SalesPerson getSalesperson() {
		return salesperson;
	}
	public void setSalesperson(SalesPerson salesperson) {
		this.salesperson = salesperson;
	}
    
}
