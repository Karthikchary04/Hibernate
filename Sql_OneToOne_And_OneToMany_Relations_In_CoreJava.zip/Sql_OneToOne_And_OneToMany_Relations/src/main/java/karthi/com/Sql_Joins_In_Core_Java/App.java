package karthi.com.Sql_Joins_In_Core_Java;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import model.Customer;
import model.SalesPerson;
import model.orders;

public class App 
{
	public void oneToOne()
	{
		Configuration cfg=new Configuration().configure().addAnnotatedClass(SalesPerson.class).addAnnotatedClass(orders.class);
        SessionFactory sf=cfg.buildSessionFactory();
        Session se=sf.openSession();
        Transaction t=se.beginTransaction();
        
        SalesPerson sp=new SalesPerson();
        sp.setSid(104);
        sp.setName("loknath");
        sp.setEmail("loknath@gmail.com");
        sp.setCity("banglore");
        
        orders o=new orders();
        o.setOid(302);
        o.setOamt(200);
        o.setProductname("Bananas");
        o.setSalesperson(sp);
        
        se.save(sp);
        se.save(o);
        t.commit();
	}
	public void oneToMany()
	{
		Configuration cfg=new Configuration().configure().addAnnotatedClass(SalesPerson.class).addAnnotatedClass(Customer.class);
        SessionFactory sf=cfg.buildSessionFactory();
        Session se=sf.openSession();
        Transaction t=se.beginTransaction();
        
        
        SalesPerson sp=new SalesPerson();
        sp.setSid(105);
        sp.setName("raja");
        sp.setEmail("raja@gmail.com");
        sp.setCity("chennai");
        
        Customer c=new Customer();
        c.setCid(204);
        c.setName("pavan");
        c.setEmail("pavan@gmail.com");
        c.setCity("bglr");
        c.getSalesPersons().add(sp);
        
        se.save(sp);
        se.save(c);
        t.commit();
        sf.close();
	}
    public static void main( String[] args )
    {
         App a=new App();
         a.oneToMany();
    }
}
