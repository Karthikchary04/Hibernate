package model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="newstudent")
public class Student 
{
	@Id
    private int sid;
    private String fullname;
	private String city;
	private String email;
    private int marks;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public String toString() 
	{
		return "Student [sid=" + sid + ", fullname=" + fullname + ", city=" + city + ", email=" + email + ", marks="
				+ marks + "]";
	}
    
}
