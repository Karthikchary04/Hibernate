package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import connectionClass.Connection;
import model.Student;

@WebServlet(urlPatterns = {"/","/Addform","/Adddetails","/getdetails","/update","/updatedetails","/retriveallrows","/retrivespecificrow"})
public class Controller extends HttpServlet
{
	 Connection c;
	 public void init() throws ServletException
	 {
		super.init();
		c=new Connection();
	 }
     public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
     {
    	 String path=req.getServletPath();
    	 Student s=new Student();
    	 if(path.equals("/"))
    	 {
    		 RequestDispatcher rd=req.getRequestDispatcher("index.jsp");
    		 rd.forward(req, res);
    	 }
    	 else if(path.equals("/Addform"))
    	 {
    		 RequestDispatcher rd=req.getRequestDispatcher("Addform.jsp");
    		 rd.forward(req, res);
    	 }
    	 else if(path.equals("/update"))
    	 {
    		 RequestDispatcher rd=req.getRequestDispatcher("update.jsp");
    		 rd.forward(req, res);
    	 }
    	 else if(path.equals("/getdetails"))
    	 {
    		 s.setSid(Integer.parseInt(req.getParameter("t1")));
    		 s=c.getDetails(s);
    		 req.setAttribute("Student",s);
    		 RequestDispatcher rd=req.getRequestDispatcher("updateform.jsp");
    		 rd.forward(req, res);
    	 }
    	 else if(path.equals("/updatedetails"))
    	 {
    		 s.setSid(Integer.parseInt(req.getParameter("t1")));
    		 s.setFullname(req.getParameter("t2"));
    		 s.setEmail(req.getParameter("t3"));
    		 s.setCity(req.getParameter("t4"));
    		 s.setMarks(Integer.parseInt(req.getParameter("t5")));
    		 boolean b=c.updateDetails(s);
    		 if(b)
    		 {
    			 req.setAttribute("msg","Details Updated Click here to <a href=index.jsp>Go Back</a>");
    			 RequestDispatcher rd=req.getRequestDispatcher("update?t1="+s.getSid()+"");
    			 rd.forward(req, res);
    		 }
    		 else
    		 {
    			 req.setAttribute("msg","Details Not Updated");
    			 RequestDispatcher rd=req.getRequestDispatcher("update?t1="+s.getSid()+"");
    			 rd.forward(req, res);
    		 }
    	 }
    	 else if(path.equals("/retriveallrows"))
    	 {
    		 ArrayList<Student> al=new ArrayList<Student>();
    		 al=c.retriveAllRows();
    		 if(al!=null)
    		 {
    		    req.setAttribute("allrows",al);
    		    RequestDispatcher rd=req.getRequestDispatcher("updateform.jsp");
    		    rd.forward(req, res);
    		 }
    	 }
    	 else if(path.equals("/retrivespecificrow"))
    	 {
    		 ArrayList<Student> al=new ArrayList<Student>();
    		 s.setSid(Integer.parseInt(req.getParameter("t1")));
    		 al=c.retriveSpecificRow(s);
    		 if(al!=null)
    		 {
    		    req.setAttribute("allrows",al);
    		    RequestDispatcher rd=req.getRequestDispatcher("updateform.jsp");
    		    rd.forward(req, res);
    		 }
    	 }
    	 else if(path.equals("/deleterow"))
    	 {
    		 s.setSid(Integer.parseInt(req.getParameter("t1")));
    		 boolean b=c.deleteRow(s);
    		 if(b)
    		 {
    			 req.setAttribute("msg","Data Deleted");
    			 RequestDispatcher rd=req.getRequestDispatcher("index.jsp");
    			 rd.forward(req, res);
    		 }
    	 }
     }
     public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
     {
    	 String path=req.getServletPath();
    	 Student s=new Student();
    	 if(path.equals("/Adddetails"))
    	 {
    		 s.setSid(Integer.parseInt(req.getParameter("t1")));
    		 s.setFullname(req.getParameter("t2"));
    		 s.setEmail(req.getParameter("t3"));
    		 s.setCity(req.getParameter("t4"));
    		 s.setMarks(Integer.parseInt(req.getParameter("t5")));
    		 boolean b=c.insert(s);
    		 if(b)
    		 { 
    			 req.setAttribute("msg","Data Inserted sucessfully");
    			 RequestDispatcher rd=req.getRequestDispatcher("Addform.jsp");
    			 rd.include(req, res);
    		 }
    		 else
    		 {
    			 req.setAttribute("msg","Data Not Inserted");
    			 RequestDispatcher rd=req.getRequestDispatcher("Addform.jsp");
    			 rd.include(req, res);
    		 }
    	 }
     }
}
