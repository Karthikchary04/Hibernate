package connectionClass;

import java.io.Serializable;
import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import model.Student;

public class Connection 
{
      SessionFactory sf=null;
      Session session=null;
      public Connection()
      {
    	  Configuration cfg=new Configuration().configure().addAnnotatedClass(Student.class);
    	  sf=cfg.buildSessionFactory();
    	  session=sf.openSession();
      }
      public boolean insert(Student s)
  	  {
    	boolean b=false;
  		Transaction tx=session.beginTransaction();
  	    int i=(Integer) session.save(s);
  	    if(i>0)
  	    {
  	    	b=true;
  	    }
  		tx.commit();
  		sf.close();
  		return b;
  	  }
      public Student getDetails(Student s)
      {
    	  s=(Student)session.get(Student.class,s.getSid());
		  return s;
      }
      public boolean updateDetails(Student st)
      {
    	  boolean b=false;
    	  Session ss=sf.openSession();
    	  Transaction tx=ss.beginTransaction();
    	  ss.update(st);
    	  tx.commit();
    	  b=true;
    	  return b;
      }
      public ArrayList<Student> retriveAllRows()
      {
    	  ArrayList<Student> al=new ArrayList<Student>();
    	  al=(ArrayList<Student>)session.createQuery("from newstudent").list();
    	  return al;
      }
      public ArrayList<Student> retriveSpecificRow(Student stu)
      {
    	  Session sse=sf.openSession();
    	  ArrayList<Student> al=new ArrayList<Student>();
    	  stu=(Student)sse.get(Student.class,stu.getSid());
    	  al.add(stu);   	  
    	  return al;
      }
      public boolean deleteRow(Student stu)
      {
    	  boolean b=false;
    	  Session sses=sf.openSession();
    	  sses.delete(stu);
    	  b=true;
    	  return b;
      }
}
