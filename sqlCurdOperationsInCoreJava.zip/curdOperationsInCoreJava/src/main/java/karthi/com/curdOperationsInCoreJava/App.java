package karthi.com.curdOperationsInCoreJava;

import java.util.ArrayList;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import model.Student;

public class App 
{
	Configuration cfg=new Configuration().configure().addAnnotatedClass(Student.class);
	SessionFactory sf=cfg.buildSessionFactory();
    Session ss=sf.openSession();
	   
	public void options()
	{
		   int opt=0;
    	   Scanner s=new Scanner(System.in);
    	   System.out.println("1.Add Students");
    	   System.out.println("2.Update Student info");
    	   System.out.println("3.View All Students");
    	   System.out.println("4.Search Students");
    	   System.out.println("5.Delete Students");
    	   do
       	   {
    	     System.out.println("Select Option");
    	     opt=s.nextInt();
    	     if(opt==1)
    	     {
    	    	 Student st=new Student();
    	    	 Transaction t=ss.beginTransaction();
    		   System.out.println("Enter Student ID");
    		   st.setSid(s.nextInt());
    		   System.out.println("Enter Student Name");
      		   st.setFullname(s.next());
    		   System.out.println("Enter Student Marks");
    		   st.setMarks(s.nextInt());
    		   System.out.println("Enter Student Email ID");
    		   st.setEmail(s.next());
    		   System.out.println("Enter Student City");
    		   st.setCity(s.next());
    		   ss.save(st);
    		   t.commit();
    	     }
    	     else if(opt==2)
    	     {
    	    	 Student st1=new Student();
    	    	 Transaction t=ss.beginTransaction();
    	    	 System.out.println("Enter Student ID to update details of student");
    	    	 st1.setSid(s.nextInt());
    	    	 st1=(Student)ss.get(Student.class,st1.getSid());
    	    	 String data="";
    	    	 while(!data.equals("update"))
    	    	 {
    	    		 System.out.println("Enter data type you want to update? Like Name,email,marks,city and after entering all values enter update to update values");
    	    		 data=s.next();
    	    		  if(data.equals("name"))
    	    		  {
    	    			  System.out.println("Enter new name");
    	    			  st1.setFullname(s.next());
    	    		  }
    	    		  else if(data.equals("email"))
    	    		  {
    	    			  System.out.println("Enter new Email");
    	    			  st1.setEmail(s.next());
    	    		  }
    	    		  else if(data.equals("marks"))
    	    		  {
    	    			  System.out.println("Enter new Marks");
    	    			  st1.setMarks(s.nextInt());
    	    		  }
    	    		  else if(data.equals("city"))
    	    		  {
    	    			  System.out.println("Enter new City");
    	    			  st1.setCity(s.next());
    	    		  }
    	    	 }
    	    	 ss.update(st1);
    	    	 t.commit();
    	     }
    	     else if(opt==3)
    	     {
    	    	 ArrayList<Student> al=new ArrayList<Student>();
    	    	 al=(ArrayList<Student>)ss.createQuery("from Student").list();
    	    	 for(Student stu:al)
    	    	 {
    	    		 System.out.println(stu.getFullname()+" "+stu.getSid()+" "+stu.getMarks()+" "+stu.getCity()+" "+stu.getEmail());
    	    	 }
    	     }
    	     else if(opt==4)
    	     {
    	    	 Student st2=new Student();
    	    	 System.out.println("Enter Student ID to retrive data");
    	    	 st2.setSid(s.nextInt());
    	    	 st2=(Student)ss.get(Student.class,st2.getSid());
    	    	 System.out.println(st2.toString());
    	     }
    	     else if(opt==5)
    	     {
    	    	 Student st3=new Student();
    	    	 Transaction t=ss.beginTransaction();
    	    	 System.out.println("Enter Student ID to delete data of student");
    	    	 st3.setSid(s.nextInt());
    	    	 ss.delete(st3.getSid());
    	    	 t.commit();
    	     }
    	}
    	while(opt!=0);
    	ss.close();
	}
	public static void main( String[] args )
    {
    	App a=new App();
    	a.options();
    }
}
